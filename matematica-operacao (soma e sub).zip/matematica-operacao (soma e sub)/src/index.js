const controllerMatematica = require('./service/Matematica-opeacao')

const soma = controllerMatematica.soma(2, 2)
const subtracao = controllerMatematica.subtracao(2, 2)
const mutiplicacao = controllerMatematica.mutiplicacao(2, 2)
const divisao = controllerMatematica.divisao(2, 2)

console.log(`O resultado da soma:      ${soma}`)
console.log(`O resultado da subtracao: ${subtracao}`)
console.log(`O resultado da subtracao: ${mutiplicacao}`)
console.log(`O resultado da divisao:   ${divisao}`)
