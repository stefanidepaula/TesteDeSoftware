const MatematicaOpeacao = require('../src/service/Matematica-opeacao')

describe('1. testando função soma', () => {
	it('1.1. Deve efetuar soma quando parametros forem positivos', () => {
		const a = 3
		const b = 2
        const valorEsperado = 5

		const resultado = MatematicaOpeacao.soma(a, b)

		expect(resultado).toBe(valorEsperado)
	})

    it('1.2. Deve efetuar soma quando parametros forem negativo', () => {
		const a = -3
		const b = -2
        const valorEsperado = -5

		const resultado = MatematicaOpeacao.soma(a, b)

		expect(resultado).toBe(valorEsperado)
	})

    it('1.3. Deve efetuar soma quando um parametros for negativo', () => {
		const a = 3
		const b = -2
        const valorEsperado = 1

		const resultado = MatematicaOpeacao.soma(a, b)

		expect(resultado).toBe(valorEsperado)
	})

    it('1.4. Não deve efetuar soma quando um parametros for maior do que o maior inteiro', () => {
		const a = Number.MAX_SAFE_INTEGER
		const b = 50
        const valorEsperado = 0

		const resultado = MatematicaOpeacao.soma(a, b)

		expect(resultado).toBeGreaterThan(valorEsperado)
	})

   
    
})

describe('2. testando função subtracao', () => {
	it('2.1. Deve efetuar a subtracao quando parametros forem positivos', () => {
		const a = 3
		const b = 2
        const valorEsperado = 1

		const resultado = MatematicaOpeacao.subtracao(a, b)

		expect(resultado).toBe(valorEsperado)
	})

    it('2.2. Deve efetuar a subtracao quando parametros forem negativo', () => {
		const a = -3
		const b = -2
        const valorEsperado = -1

		const resultado = MatematicaOpeacao.subtracao(a, b)

		expect(resultado).toBe(valorEsperado)
	})

    it('2.3. Deve efetuar a subtracao quando um parametros for negativo', () => {
		const a = 3
		const b =  -2
        const valorEsperado = 5

		const resultado = MatematicaOpeacao.subtracao(a, b)

		expect(resultado).toBe(valorEsperado)
	})
})

describe('3. testando função mutiplicação', () => {
	it('3.1. Deve efetuar a mutiplicação quando parametros forem positivos', () => {
		const a = 3
		const b = 2
        const valorEsperado = 6

		const resultado = MatematicaOpeacao.mutiplicacao(a, b)

		expect(resultado).toBe(valorEsperado)
	})

    it('3.2. Deve efetuar a mutiplicação quando parametros forem negativo', () => {
		const a = -3
		const b = -2
        const valorEsperado = 6

		const resultado = MatematicaOpeacao.mutiplicacao(a, b)

		expect(resultado).toBe(valorEsperado)
	})

    it('3.3. Deve efetuar a mutiplicação quando um parametros for negativo', () => {
		const a = 3
		const b =  -2
        const valorEsperado = -6

		const resultado = MatematicaOpeacao.mutiplicacao(a, b)

		expect(resultado).toBe(valorEsperado)
	})
})


