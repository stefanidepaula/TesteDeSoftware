const controllerMatematica = require('./service/Matematica-opeacao')

const soma = controllerMatematica.soma(2, 2)
const subtracao = controllerMatematica.subtracao(2, 2)
const mutiplicacao = controllerMatematica.mutiplicacao(2, 2)
const divisao = controllerMatematica.divisao(2, 2)

console.log(soma)
console.log(subtracao)
console.log(mutiplicacao)
console.log(divisao)
