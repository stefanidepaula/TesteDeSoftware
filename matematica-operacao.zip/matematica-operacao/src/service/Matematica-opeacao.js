class MatematicaOpeacao {

    soma(a, b) {
        if ( typeof a === 'number' && typeof b == 'number') {  
            return a + b
        }
    }

    subtracao(a, b) {
        if ( typeof a === 'number' && typeof b == 'number') {
            return a - b
        }
    }

    mutiplicacao(a, b) {
        if ( typeof a === 'number' && typeof b == 'number') {
            return a * b
        }
    }

    divisao(a, b) {
        if ( typeof a === 'number' && typeof b == 'number') {
            return a / b
        }
    }
}

module.exports = new MatematicaOpeacao()